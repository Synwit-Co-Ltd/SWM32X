#ifndef __BSP_SDIO_H
#define __BSP_SDIO_H

#include "SWM320.h"

uint8_t bsp_SDIOInit(void);

#endif
