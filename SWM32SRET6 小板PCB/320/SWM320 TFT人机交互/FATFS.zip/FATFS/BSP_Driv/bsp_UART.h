#ifndef __BSP_UART_H
#define __BSP_UART_H

#include "SWM320.h"

void SerialInit(uint32_t u32Bound);

#endif 
