#ifndef __BSP_SYSTICK_H
#define __BSP_SYSTICK_H

#include "SWM320.h"

void SysTick_Init(void);
void SWM_Delay(__IO uint32_t Delay);

#endif 

