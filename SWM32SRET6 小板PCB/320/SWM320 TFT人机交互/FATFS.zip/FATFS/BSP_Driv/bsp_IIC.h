#ifndef __BSP_IIC_H
#define __BSP_IIC_H

#include "SWM3200.h"

void I2C_Mst_Init(void);

#endif 
